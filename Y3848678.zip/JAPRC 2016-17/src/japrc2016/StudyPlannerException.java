package japrc2016;

public class StudyPlannerException extends RuntimeException
{
    public StudyPlannerException(String message)
    {
        super(message);
    }
}
